import React, { Component } from 'react';
import Home from './components/HomeComp';
import './App.css';

class App extends Component{
  render(){
    return(
      <Home />
    );
  }
}

export default App;
